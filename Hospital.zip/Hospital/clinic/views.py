from django.shortcuts import render
from .models import Users
from .models import Feed
from .models import  Work

# Create your views here.
def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')


def gallery(request):
    return render(request,'gallery.html')

def resume(request):
    return render(request,'resume.html')

def contact(request):
    feed_list=Feed.objects.all()
    return render(request,'contact.html',{'list':feed_list})
    

def home2(request):
    return render(request,'home2.html')

def skincare(request):
    return render(request,'skincare.html')

def dentalScience(request):
    return render(request,'dentalScience.html')

def criticalCare(request):
    return render(request,'criticalCare.html') 


def evm(request):
    return render(request,'evm.html') 


def withus(request):
    if request.method =='GET':
        return render(request,'withus.html') 
    if request.method =='POST':
        try:
            fname=request.POST.get('fname')
            lname=request.POST.get('lname')
            email=request.POST.get('email')
            mobile=request.POST.get('mobile')
            file=request.POST.get('file')
            messag=request.POST.get('messag')
            wo = Work()
            wo.fname=fname
            wo.lname=lname
            wo.email=email
            wo.mobile=mobile
            wo.file=file
            wo.messag=messag
            wo.save()
            return render(request,'withus.html',{'msg':'Uploaded Successfully','tag':'success'})
        except Exception:
            return render(request,'withus.html',{'msg':'Error in uploading','tag':'danger'})






def feedback(request):
    if request.method =='GET':
        return render(request,'feedback.html')
 
    if request.method =='POST':
        try:
            fname=request.POST.get('fname')
            lname=request.POST.get('lname')
            email=request.POST.get('email')
            mobile=request.POST.get('mobile')
            messag=request.POST.get('messag')
            feed = Feed()
            feed.fname=fname
            feed.lname=lname
            feed.email=email
            feed.mobile=mobile
            feed.messag=messag
            feed.save()
            return render(request,'feedback.html',{'msg':'Uploaded Successfully','tag':'success'})
        except Exception:
            return render(request,'feedback.html',{'msg':'Error in uploading','tag':'danger'})


    return render(request,'feedback.html') 

def appoint(request):
     if request.method == 'GET':
        return render(request,'appoint.html')
     
     if request.method == 'POST':
        try:
            name = request.POST.get('name')
            age = request.POST.get('age')
            gender = request.POST.get('gender')
            adhar_number=request.POST.get('adhar_number')
            mobile = request.POST.get('mobile')
            appoint_department=request.POST.get('appoint_department')
            #print(name,email,password,mobile)
            user = Users()
            user.name = name
            user.age = age
            user.adhar_number=adhar_number
            user.gender = gender
            user.mobile = mobile
            user.appoint_department=appoint_department
            user.save()
            return render(request,'appoint.html',{'msg':'Successfully appointed','tag':'success'})
        except Exception:
            return render(request,'appoint.html',{'msg':'Error in appoint','tag':'danger'})


def todayapp(request):
    user_list=Users.objects.all()
    return render(request,'todayapp.html',{'list':user_list})


def singleapp(request,id):
    user=Users.objects.get(id=id)
    return render(request,'singleapp.html',{'user':user}) 

def deluser(request,id):
    Users.objects.filter(id=id).delete()
    user_list=Users.objects.all()
    return render(request,'todayapp.html',{ 'list':user_list})