from django.db import models

# Create your models here.
class Users(models.Model):
    name=models.CharField(max_length=80)
    age=models.CharField(max_length=3)
    adhar_number=models.CharField(max_length=12)
    gender=models.CharField(max_length=20)
    mobile=models.CharField(max_length=20)
    appoint_department=models.CharField(max_length=100)

class Feed(models.Model):
    fname=models.CharField(max_length=40)
    lname=models.CharField(max_length=50)
    email=models.EmailField(max_length=40)
    mobile=models.CharField(max_length=20)
    messag=models.CharField(max_length=100)

class Work(models.Model):
    fname=models.CharField(max_length=40)
    lname=models.CharField(max_length=50)
    email=models.EmailField(max_length=40)
    mobile=models.CharField(max_length=20)
    file=models.CharField(max_length=7000)
    messag=models.CharField(max_length=100)

